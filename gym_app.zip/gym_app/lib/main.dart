import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'GYM Health App',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        fontFamily: 'Roboto', // Modern font
      ),
      initialRoute: '/',
      routes: {
        '/': (context) => HomePage(),
        '/workout': (context) => WorkoutPage(),
        '/tips': (context) => TipsPage(),
      },
    );
  }
}

class HomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        padding: const EdgeInsets.all(20.0),
        color: Colors.blue[800], // Darker blue for the whole background
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Icon(
                Icons.fitness_center,
                size: 120,
                color: Colors.white,
              ),
              SizedBox(height: 20),
              Text(
                'Selamat datang di Aplikasi Kesehatan GYM!',
                style: TextStyle(
                  fontSize: 32,
                  fontWeight: FontWeight.w900, // Bold and large
                  color: Colors.white,
                  fontFamily: 'Raleway', // More stylish font for welcome message
                ),
                textAlign: TextAlign.center,
              ),
              SizedBox(height: 40),
              ElevatedButton(
                onPressed: () {
                  Navigator.pushNamed(context, '/workout');
                },
                style: ElevatedButton.styleFrom(
                  padding: EdgeInsets.symmetric(horizontal: 50, vertical: 15),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(30), // Rounded buttons
                  ),
                  backgroundColor: Colors.blue[600], // Slightly lighter blue for button
                ),
                child: Text(
                  'Mulai Latihan',
                  style: TextStyle(fontSize: 18, color: Colors.white), // White text for contrast
                ),
              ),
              SizedBox(height: 20),
              ElevatedButton(
                onPressed: () {
                  Navigator.pushNamed(context, '/tips');
                },
                style: ElevatedButton.styleFrom(
                  padding: EdgeInsets.symmetric(horizontal: 50, vertical: 15),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(30),
                  ),
                  backgroundColor: Colors.blue[600], // Same style as other button
                ),
                child: Text(
                  'Tips Kesehatan',
                  style: TextStyle(fontSize: 18, color: Colors.white), // White text for contrast
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class WorkoutPage extends StatelessWidget {
  final List<String> workouts = [
    'Push-up',
    'Squat',
    'Deadlift',
    'Bench Press',
    'Pull-up',
  ];

  final Map<String, String> workoutDescriptions = {
    'Push-up': 'Latihan dasar untuk memperkuat tubuh bagian atas.',
    'Squat': 'Latihan untuk tubuh bagian bawah guna meningkatkan kekuatan.',
    'Deadlift': 'Latihan seluruh tubuh yang fokus pada rantai posterior.',
    'Bench Press': 'Latihan untuk membangun kekuatan di dada.',
    'Pull-up': 'Latihan menggunakan berat badan untuk kekuatan tubuh bagian atas.',
  };

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        color: Colors.blue[700], // Consistent blue background
        padding: const EdgeInsets.all(12.0),
        child: Center(
          child: Column(
            children: <Widget>[
              Expanded(
                child: ListView.builder(
                  itemCount: workouts.length,
                  itemBuilder: (context, index) {
                    return GestureDetector(
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => ExerciseDetailPage(
                              exerciseName: workouts[index],
                              description: workoutDescriptions[workouts[index]]!,
                            ),
                          ),
                        );
                      },
                      child: Card(
                        elevation: 5,
                        margin: EdgeInsets.symmetric(vertical: 10),
                        color: Colors.blue[500], // Consistent card color in blue tones
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(15),
                        ),
                        child: ListTile(
                          title: Center(
                            child: Text(
                              workouts[index],
                              style: TextStyle(fontWeight: FontWeight.bold, color: Colors.white),
                            ),
                          ),
                          subtitle: Center(
                            child: Text(
                              'Deskripsi dari ' + workouts[index],
                              style: TextStyle(color: Colors.white70),
                              textAlign: TextAlign.center,
                            ),
                          ),
                          trailing: Icon(Icons.arrow_forward_ios, color: Colors.white),
                        ),
                      ),
                    );
                  },
                ),
              ),
              ElevatedButton(
                onPressed: () {
                  Navigator.pushNamed(context, '/');
                },
                style: ElevatedButton.styleFrom(
                  padding: EdgeInsets.symmetric(horizontal: 50, vertical: 15),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(30),
                  ),
                  backgroundColor: Colors.blue[600], // Same style as other button
                ),
                child: Text(
                  'Kembali ke Home',
                  style: TextStyle(fontSize: 18, color: Colors.white), // White text for contrast
                ),
              ),
              SizedBox(height: 20),
            ],
          ),
        ),
      ),
    );
  }
}

class ExerciseDetailPage extends StatelessWidget {
  final String exerciseName;
  final String description;

  ExerciseDetailPage({required this.exerciseName, required this.description});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        color: Colors.blue[700], // Consistent background color for details
        padding: const EdgeInsets.all(20.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Container(
              padding: EdgeInsets.all(16.0),
              decoration: BoxDecoration(
                color: Colors.blue[500],
                borderRadius: BorderRadius.circular(15),
              ),
              child: Center(
                child: Text(
                  exerciseName,
                  style: TextStyle(fontSize: 30, fontWeight: FontWeight.bold, color: Colors.white),
                  textAlign: TextAlign.center,
                ),
              ),
            ),
            SizedBox(height: 20),
            Card(
              elevation: 4,
              color: Colors.blue[400], // Blue themed card
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Center(
                  child: Text(
                    description,
                    style: TextStyle(fontSize: 18, color: Colors.white),
                    textAlign: TextAlign.center,
                  ),
                ),
              ),
            ),
            SizedBox(height: 20),
            Text(
              'Tips untuk latihan ini:',
              style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: Colors.white),
              textAlign: TextAlign.center, // Centering the tips header
            ),
            SizedBox(height: 10),
            Card(
              elevation: 4,
              color: Colors.blue[300],
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center, // Centering the tips
                  children: [
                    Text(
                      '1. Jaga bentuk yang benar.',
                      style: TextStyle(fontSize: 16, color: Colors.white),
                      textAlign: TextAlign.center, // Centering the text
                    ),
                    SizedBox(height: 5),
                    Text(
                      '2. Bernafas dengan benar.',
                      style: TextStyle(fontSize: 16, color: Colors.white),
                      textAlign: TextAlign.center, // Centering the text
                    ),
                    SizedBox(height: 5),
                    Text(
                      '3. Mulai dengan beban yang lebih ringan dan tingkatkan secara bertahap.',
                      style: TextStyle(fontSize: 16, color: Colors.white),
                      textAlign: TextAlign.center, // Centering the text
                    ),
                  ],
                ),
              ),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                Navigator.pushNamed(context, '/');
              },
              style: ElevatedButton.styleFrom(
                padding: EdgeInsets.symmetric(horizontal: 50, vertical: 15),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(30),
                ),
                backgroundColor: Colors.blue[600], // Same style as other button
              ),
              child: Text(
                'Kembali ke Home',
                style: TextStyle(fontSize: 18, color: Colors.white), // White text for contrast
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class TipsPage extends StatelessWidget {
  final List<String> tips = [
    'Jaga tubuh tetap terhidrasi.',
    'Konsumsi makanan seimbang.',
    'Dapatkan cukup tidur.',
    'Lakukan pemanasan sebelum latihan.',
    'Lakukan pendinginan setelah latihan.',
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Tips Kesehatan'),
        centerTitle: true,
        backgroundColor: Colors.blue[800],
      ),
      body: Container(
        color: Colors.blue[700], // Blue background
        padding: const EdgeInsets.all(12.0),
        child: Column( // Ganti ListView dengan Column
          children: [
            Expanded( // Menggunakan Expanded agar ListView dapat menggunakan ruang yang tersisa
              child: ListView.builder(
                itemCount: tips.length,
                itemBuilder: (context, index) {
                  return Card(
                    color: Colors.blue[500], // Blue card color for tips
                    elevation: 5,
                    margin: EdgeInsets.symmetric(vertical: 10),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(15),
                    ),
                    child: Padding(
                      padding: const EdgeInsets.all(16.0),
                      child: Text(
                        tips[index],
                        style: TextStyle(
                          fontSize: 18,
                          fontStyle: FontStyle.italic,
                          color: Colors.white,
                        ),
                        textAlign: TextAlign.center,
                      ),
                    ),
                  );
                },
              ),
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.pushNamed(context, '/');
              },
              style: ElevatedButton.styleFrom(
                padding: EdgeInsets.symmetric(horizontal: 50, vertical: 15),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(30),
                ),
                backgroundColor: Colors.blue[600], // Same style as other button
              ),
              child: Text(
                'Kembali ke Home',
                style: TextStyle(fontSize: 18, color: Colors.white), // White text for contrast
              ),
            ),
            SizedBox(height: 20),
          ],
        ),
      ),
    );
  }
}
